Home Garden Master Assets

Included PNG assets:
- 9 orchard trees: large plum, molly apple, liberty apple, gala apple, williams pride apple, crabapple, regular peach, dwarf peach, dwarf pear
- Roses: 1 hot pink, 2 soft pink
- Perennials/herbs: white peonies, blue irises, creeping thyme, purple salvia
- Shrubs: golden euonymus, flat top juniper
- Landscape trees: eastern pine, green dogwood, red dogwood, hot pink crepe myrtle, sweetgum tree, old cherry tree

Note: Additional later-requested items like sage, rosemary, daffodils, coneflowers, and blueberry variants are not yet included as separate cutouts in this zip.
