Home Garden additional assets: rosemary, sage, blueberry, pink lemonade blueberry, mint, green thyme, strawberries, regular cherry tree, echinacea, and black chain-link gate.
