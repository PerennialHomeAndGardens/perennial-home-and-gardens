Home Garden vegetable assets extracted as transparent PNGs.
